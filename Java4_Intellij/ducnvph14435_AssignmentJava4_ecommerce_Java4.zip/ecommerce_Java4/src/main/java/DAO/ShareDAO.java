package DAO;

public class ShareDAO {
}
