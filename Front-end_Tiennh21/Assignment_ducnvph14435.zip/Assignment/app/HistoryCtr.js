app.controller('myHistory', function ($scope){
    
})